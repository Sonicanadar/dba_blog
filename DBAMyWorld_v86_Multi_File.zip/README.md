# DBAMyWorld v86 – Multi-File Performance Build

## Files
- `index.html` – main website
- `css/style.css` – all site CSS
- `js/core.js` – core navigation, data, dashboard, bookmarks and active modules
- `js/oracle-dba-lab.js` – Oracle DBA Lab, loaded only when opened
- `js/interview-center.js` – Interview Center, loaded only when opened
- `js/sql-practice.js` – SQL Practice Center, loaded only when opened

## GitHub Pages
Upload the complete folder contents to the repository root. The site entry point is `index.html`. Keep the `css` and `js` folders in the same relative locations.

## Important
Do not upload only `index.html`; the CSS and JavaScript files are required.
